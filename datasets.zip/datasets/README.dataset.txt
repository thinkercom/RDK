# Small Object Detection (sahi) Object Detection > 2025-06-06 8:25pm
https://universe.roboflow.com/mount-chen/small-object-detection-sahi-object-detection-waibm

Provided by a Roboflow user
License: CC BY 4.0

